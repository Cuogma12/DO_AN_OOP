/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLTV;

import view.Home;

/**
 *
 * @author chipn
 */
public class QLTV {

    public static void main(String[] args) {
        Home home = new Home();
        home.setVisible(true);
        home.setLocationRelativeTo(null);
    }
}
