package view;

import model.ConnectDB;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
//import model.Statistics;

public class Thong_ke_sach extends javax.swing.JFrame {

    public Thong_ke_sach() {
        initComponents();
        loadBang();
    }

    public void loadBang() {
        try {
            // Kết nối database
            Connection con = ConnectDB.getConnection();

            // Thực thi truy vấn SQL
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT SACH.MA_SACH,TEN_SACH , DOC_GIA.TEN_DG , THE_LOAI,TEN_TG , NGAY_TRA , TINH_TRANG \n"
                    + "FROM SACH INNER JOIN SACH_PHIEUMUON ON SACH.MA_SACH = SACH_PHIEUMUON.MA_SACH \n"
                    + "			INNER JOIN PHIEU_MUON_TRA ON SACH_PHIEUMUON.MA_PHIEU = PHIEU_MUON_TRA.MA_PHIEU\n"
                    + "            INNER JOIN DOC_GIA ON DOC_GIA.MA_DG = PHIEU_MUON_TRA.MA_DG");

            // Cấu hình model JTable
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.setColumnIdentifiers(new String[]{"Mã sách", "Tên sách", "Tên đọc giả", "Thể loại","Tác giả" ,"Ngày trả", "Tình trạng" ,"Trạng thái sách"});

            // Lấy dữ liệu từ ResultSet và thêm vào model
            while (rs.next()) {
                java.util.Date ngayTra = rs.getDate(6);
                java.util.Date currentTime = new java.util.Date();
                String ting_trang;

                if (ngayTra.before(currentTime)) {
                    ting_trang = "Đã hết hạn";
                } else {
                    ting_trang = "Chưa trả";
                }
                tableModel.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5) ,rs.getDate(6) ,ting_trang ,rs.getString(7)});
            }

            // Cài đặt model cho JTable
            tabSach.setModel(tableModel);
            con.close();
            st.close();
            rs.close();
        } catch (SQLException e) {

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        txtTensach = new javax.swing.JTextField();
        btnTimkiem = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabSach = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        btnTk_ds = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/big-thong-ke-icon.png"))); // NOI18N
        jLabel1.setText("THỐNG KÊ SÁCH");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Tên sách:");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/undo-icon.png"))); // NOI18N
        jButton1.setText("Quay lại");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnTimkiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/mini-search-icon.png"))); // NOI18N
        btnTimkiem.setText("Tìm kiếm");
        btnTimkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimkiemActionPerformed(evt);
            }
        });

        tabSach.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabSach.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                tabSachComponentShown(evt);
            }
        });
        jScrollPane1.setViewportView(tabSach);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/refresh-icon.png"))); // NOI18N
        jButton2.setText("Làm mới");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnTk_ds.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/thong-ke-icon.png"))); // NOI18N
        btnTk_ds.setText("Thống kê đầu sách");
        btnTk_ds.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTk_dsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(22, 22, 22)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 871, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtTensach, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jButton2)
                                            .addGap(84, 84, 84)
                                            .addComponent(btnTk_ds))
                                        .addComponent(btnTimkiem))
                                    .addGap(106, 106, 106))))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(310, 310, 310)
                            .addComponent(jLabel1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(391, 391, 391)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTensach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTk_ds, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MenuTT tt = new MenuTT();
        tt.setVisible(true);
        tt.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tabSachComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_tabSachComponentShown
        loadBang();
    }//GEN-LAST:event_tabSachComponentShown

    private void btnTimkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimkiemActionPerformed
        try {
            Connection con = ConnectDB.getConnection();
            String tim_kiem = "SELECT SACH.MA_SACH,TEN_SACH , DOC_GIA.TEN_DG , THE_LOAI,TEN_TG ,NGAY_TRA , TINH_TRANG \n"
                    + "FROM SACH INNER JOIN SACH_PHIEUMUON ON SACH.MA_SACH = SACH_PHIEUMUON.MA_SACH \n"
                    + "			INNER JOIN PHIEU_MUON_TRA ON SACH_PHIEUMUON.MA_PHIEU = PHIEU_MUON_TRA.MA_PHIEU\n"
                    + "            INNER JOIN DOC_GIA ON DOC_GIA.MA_DG = PHIEU_MUON_TRA.MA_DG\n"
                    +"WHERE TEN_SACH='"+txtTensach.getText()+"'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(tim_kiem);
            ((DefaultTableModel) tabSach.getModel()).setRowCount(0);
            while (rs.next()) {
                java.util.Date ngayTra = rs.getDate(6);
                java.util.Date currentTime = new java.util.Date();
                String ting_trang;

                if (ngayTra.before(currentTime)) {
                    ting_trang = "Đã hết hạn";
                } else {
                    ting_trang = "Chưa trả";
                }
                Object[] row = new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getDate(6),ting_trang,rs.getString(7) };
                ((DefaultTableModel) tabSach.getModel()).addRow(row);
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnTimkiemActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       loadBang();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnTk_dsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTk_dsActionPerformed
        Thong_ke_ds tkds = new Thong_ke_ds();
        tkds.setVisible(true);
        tkds.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnTk_dsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Thong_ke_sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Thong_ke_sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Thong_ke_sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Thong_ke_sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Thong_ke_sach().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnTimkiem;
    private javax.swing.JButton btnTk_ds;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabSach;
    private javax.swing.JTextField txtTensach;
    // End of variables declaration//GEN-END:variables

}
