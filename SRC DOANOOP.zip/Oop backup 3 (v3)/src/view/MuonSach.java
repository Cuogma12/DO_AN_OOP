//MuonSach
package view;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.ConnectDB;
import model.Reader;
import model.CallCard;
import model.Book_Card;
import model.Sum;

public class MuonSach extends javax.swing.JFrame {

    /**
     * Creates new form MuonSach
     */
    public MuonSach() {
        initComponents();
        loadBangMS();

    }

    public void loadBangMS() {
        try {

            // Cấu hình model JTable
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.setColumnIdentifiers(new String[]{"Mã sách", "Tên sách", "Thể loại", "Tên TG", "Giá cọc", "Ngày mượn", "Ngày trả"});

            // Cài đặt model cho JTable
            tabMS.setModel(tableModel);

        } catch (Exception e) {

        }
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtMaS = new javax.swing.JTextField();
        btnMuonS = new javax.swing.JButton();
        btnHuy = new javax.swing.JButton();
        btnTim = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabMS = new javax.swing.JTable();
        btnXoa = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/sl-sach-icon.png"))); // NOI18N
        jLabel1.setText("MƯỢN SÁCH");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Mã sách :");

        btnMuonS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/sl-sach-icon.png"))); // NOI18N
        btnMuonS.setText("Mượn sách");
        btnMuonS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMuonSActionPerformed(evt);
            }
        });

        btnHuy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/undo-icon.png"))); // NOI18N
        btnHuy.setText("Quay lại");
        btnHuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyActionPerformed(evt);
            }
        });

        btnTim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/mini-search-icon.png"))); // NOI18N
        btnTim.setText("Tìm kiếm");
        btnTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimActionPerformed(evt);
            }
        });

        tabMS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabMS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabMSMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabMS);

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/delete-book-icon.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/huce-48.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 551, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 41, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator1)
                .addGap(6, 6, 6))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(86, 86, 86)
                                .addComponent(btnMuonS)
                                .addGap(83, 83, 83)
                                .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtMaS, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(btnTim))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)
                        .addGap(160, 160, 160)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(261, 261, 261)
                        .addComponent(btnHuy, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMaS)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(btnTim, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMuonS, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHuy, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyActionPerformed
        MenuDocgia mndg = new MenuDocgia();
        mndg.setVisible(true);
        mndg.setLocationRelativeTo(null);
        this.dispose();

    }//GEN-LAST:event_btnHuyActionPerformed

    private void btnTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimActionPerformed
        DefaultTableModel tableModel = (DefaultTableModel) tabMS.getModel();
        try {
            if (txtMaS.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "Không được bỏ trống mã sách", "", JOptionPane.ERROR_MESSAGE);
            }
            String mas = txtMaS.getText();
            if (mas.length() < 5) {
                JOptionPane.showMessageDialog(this, "Mã sách phải đủ 5 kí tự");
            }
            if (mas.length() == 5) {
                Connection con = ConnectDB.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT MA_SACH, TEN_SACH, THE_LOAI, TEN_TG, GIA_COC,CURRENT_DATE() AS NGAY_MUON ,DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH) AS NGAY_TRA\n"
                        + "FROM SACH\n"
                        + "WHERE MA_SACH='" + txtMaS.getText() + "'\n"
                        + "GROUP BY TEN_SACH, THE_LOAI, TEN_TG, GIA_COC");

                if (rs.next()) {
                    Object[] row = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)};
                    tableModel.addRow(row); // Insert at row 0

                }
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnTimActionPerformed


    private void btnMuonSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMuonSActionPerformed

        try {
            DefaultTableModel tableModel = (DefaultTableModel) tabMS.getModel();
            Connection con = ConnectDB.getConnection();
            Statement st = con.createStatement();
            if (txtMaS.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "Không được bỏ trống mã sách", "", JOptionPane.ERROR_MESSAGE);
            }
            String sql = "SELECT CURRENT_DATE() AS NGAY_MUON, DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH) AS NGAY_TRA\n"
                    + "FROM SACH\n"
                    + "WHERE MA_SACH='" + txtMaS.getText() + "'";
            ResultSet rs_t = st.executeQuery(sql);

            if (rs_t.next()) {
                String ngay_m = rs_t.getString(1);
                String ngay_t = rs_t.getString(2);
                Reader dg = new Reader();
                String mad = Reader.getRea_ID();
                CallCard pmt = new CallCard();
                pmt.setBorrowDate(ngay_m);
                pmt.setReturnDate(ngay_t);
                int rowCount = tabMS.getRowCount();
                int sl = 0;
                for (int i = 0; i < rowCount; i++) {
                    sl++;

                }
                float tong = 0;
                float giaCoc;
                for (int i = 0; i < rowCount; i++) {
                    String giaCocString = (String) tableModel.getValueAt(i, 4);
                    giaCoc = Float.parseFloat(giaCocString);
                    tong+=giaCoc;
                }
                Sum tt = new Sum();
                tt.setSum(tong);
                pmt.setBorrowNum(sl);
                pmt.setStatus("Đang mượn");
                String tao_p = "INSERT INTO PHIEU_MUON_TRA (MA_DG , NGAY_MUON , NGAY_TRA , SO_LUONG_MUON ) VALUES\n"
                        + "	('" + mad + "','" + ngay_m + "','" + ngay_t + "',	'" + pmt.getBorrowNum() + "'	)";
                int kq = st.executeUpdate(tao_p);
                if (kq > 0) {
                    JOptionPane.showMessageDialog(this, "Mượn thành công! \n" 
                            + "Số tiền cần cọc sách là :" + tt.getSum() +"\n"
                            +"Vui lòng ra quầy Thủ Thư để thanh toán !" );
                }

            }

            Reader dg = new Reader();
            String mad = Reader.getRea_ID();
            String pm_t = "SELECT MA_PHIEU FROM PHIEU_MUON_TRA WHERE MA_DG ='" + mad + "'";
            rs_t = st.executeQuery(pm_t);
            if (rs_t.next()) {
                CallCard pmt = new CallCard();
                String map = rs_t.getString(1);
                pmt.setCard_ID(map);
                int rowCount = tabMS.getRowCount();
                int sl_s = 1;

                String tt = "Đang mượn";
                Book_Card spm = new Book_Card();
                spm.setNumber(sl_s);
                spm.setSta_tus(tt);

                for (int i = 0; i < rowCount; i++) {
                    String ma = (String) tabMS.getValueAt(i, 0);
                    String s_pm = "INSERT INTO SACH_PHIEUMUON VALUES\n"
                            + "('" + pmt.getCard_ID() + "',	'" + ma + "' ,'" + sl_s + "' ,'" + tt + "')";
                    st.executeUpdate(s_pm);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Có lỗi", "", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnMuonSActionPerformed

    private void tabMSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabMSMouseClicked

    }//GEN-LAST:event_tabMSMouseClicked

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        DefaultTableModel model = (DefaultTableModel) tabMS.getModel();
        int selectedRow = tabMS.getSelectedRow();
        if (selectedRow != -1) { // Kiểm tra hàng đã được chọn hay chưa
            model.removeRow(selectedRow);
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MuonSach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MuonSach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MuonSach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MuonSach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MuonSach().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHuy;
    private javax.swing.JButton btnMuonS;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tabMS;
    private javax.swing.JTextField txtMaS;
    // End of variables declaration//GEN-END:variables

}
