/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.ConnectDB;
import model.Reader;
import model.CallCard;
import model.Book_Card;
import model.Sum;

/**
 *
 * @author chipn
 */
public class Quan_ly_muon extends javax.swing.JFrame {

  
    public Quan_ly_muon() {
        initComponents();
        loadBangMS();
    }

    public void loadBangMS() {
        try {

            // Cấu hình model JTable
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.setColumnIdentifiers(new String[]{"Mã sách", "Tên sách", "Thể loại", "Tên TG", "Giá cọc", "Ngày mượn", "Ngày trả"});

            // Cài đặt model cho JTable
            tabSach.setModel(tableModel);

        } catch (Exception e) {

        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtMas = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabSach = new javax.swing.JTable();
        btnQuayL = new javax.swing.JButton();
        btnHoanThanh = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtM_dg = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/buy-icon.png"))); // NOI18N
        jLabel1.setText("QUẢN LÝ MƯỢN");

        jLabel2.setText("Mã sách :");

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/add-book-icon.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/delete-book-icon.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        tabSach.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabSach);

        btnQuayL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/undo-icon.png"))); // NOI18N
        btnQuayL.setText("Quay lại");
        btnQuayL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuayLActionPerformed(evt);
            }
        });

        btnHoanThanh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Done-icon.png"))); // NOI18N
        btnHoanThanh.setText("Hoàn thành");
        btnHoanThanh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHoanThanhActionPerformed(evt);
            }
        });

        jLabel3.setText("Mã đọc giả :");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/huce-48.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jLabel2))
                                    .addComponent(jLabel3))
                                .addGap(22, 22, 22)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtMas, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtM_dg, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(82, 82, 82)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(61, 61, 61)
                                        .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btnHoanThanh)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 28, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jButton1)
                .addGap(173, 173, 173)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnQuayL, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(308, 308, 308))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtMas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtM_dg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(29, 29, 29))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnHoanThanh, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnXoa)
                            .addComponent(btnThem))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnQuayL, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnQuayLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuayLActionPerformed
        MenuTT mntt = new MenuTT();
        mntt.setVisible(true);
        mntt.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnQuayLActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        DefaultTableModel tableModel = (DefaultTableModel) tabSach.getModel();
        try {
            if (txtMas.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "Không được bỏ trống mã sách", "", JOptionPane.ERROR_MESSAGE);
            }
            String mas = txtMas.getText();
            if (mas.length() < 5) {
                JOptionPane.showMessageDialog(this, "Mã sách phải đủ 5 kí tự");
            }
            if (mas.length() == 5) {
                Connection con = ConnectDB.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT MA_SACH, TEN_SACH, THE_LOAI, TEN_TG, GIA_COC,CURRENT_DATE() AS NGAY_MUON ,DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH) AS NGAY_TRA\n"
                        + "FROM SACH\n"
                        + "WHERE MA_SACH='" + txtMas.getText() + "'\n"
                        + "GROUP BY TEN_SACH, THE_LOAI, TEN_TG, GIA_COC");

                if (rs.next()) {
                    Object[] row = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)};
                    tableModel.addRow(row); // Insert at row 0

                }
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        DefaultTableModel model = (DefaultTableModel) tabSach.getModel();
        int selectedRow = tabSach.getSelectedRow();
        if (selectedRow != -1) { // Kiểm tra hàng đã được chọn hay chưa
            model.removeRow(selectedRow);
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnHoanThanhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHoanThanhActionPerformed
        
        try {
            DefaultTableModel tableModel = (DefaultTableModel) tabSach.getModel();
            Connection con = ConnectDB.getConnection();
            Statement st = con.createStatement();
            if (txtMas.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "Không được bỏ trống mã sách", "", JOptionPane.ERROR_MESSAGE);
            }
            String sql = "SELECT CURRENT_DATE() AS NGAY_MUON, DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH) AS NGAY_TRA\n"
                    + "FROM SACH\n"
                    + "WHERE MA_SACH='" + txtMas.getText() + "'";
            ResultSet rs_t = st.executeQuery(sql);

            if (rs_t.next()) {
                String ngay_m = rs_t.getString(1);
                String ngay_t = rs_t.getString(2);
              
                String mad = txtM_dg.getText();
                CallCard pmt = new CallCard();
                pmt.setBorrowDate(ngay_m);
                pmt.setReturnDate(ngay_t);
                int rowCount = tabSach.getRowCount();
                int sl = 0;
                for (int i = 0; i < rowCount; i++) {
                    sl++;

                }
                float tong = 0;
                float giaCoc;
                for (int i = 0; i < rowCount; i++) {
                    String giaCocString = (String) tableModel.getValueAt(i, 4);
                    giaCoc = Float.parseFloat(giaCocString);
                    tong+=giaCoc;
                }
                Sum tt = new Sum();
                tt.setSum(tong);
                pmt.setBorrowNum(sl);
                pmt.setStatus("Đang mượn");
                String tao_p = "INSERT INTO PHIEU_MUON_TRA (MA_DG , NGAY_MUON , NGAY_TRA , SO_LUONG_MUON ) VALUES\n"
                        + "	('" + mad + "','" + ngay_m + "','" + ngay_t + "',	'" + pmt.getBorrowNum() + "'	)";
                int kq = st.executeUpdate(tao_p);
                if (kq > 0) {
                    JOptionPane.showMessageDialog(this, "Mượn thành công! \n" 
                            + "Số tiền cần cọc sách là :" + tt.getSum() +"\n"
                             );
                }

            }

            
            String mad = txtM_dg.getText();
            String pm_t = "SELECT MA_PHIEU FROM PHIEU_MUON_TRA WHERE MA_DG ='" + mad + "'";
            rs_t = st.executeQuery(pm_t);
            if (rs_t.next()) {
                CallCard pmt = new CallCard();
                String map = rs_t.getString(1);
                pmt.setCard_ID(map);
                int rowCount = tabSach.getRowCount();
                int sl_s = 1;

                String tt = "Đang mượn";
                Book_Card spm = new Book_Card();
                spm.setNumber(sl_s);
                spm.setSta_tus(tt);

                for (int i = 0; i < rowCount; i++) {
                    String ma = (String) tabSach.getValueAt(i, 0);
                    String s_pm = "INSERT INTO SACH_PHIEUMUON VALUES\n"
                            + "('" + pmt.getCard_ID() + "',	'" + ma + "' ,'" + sl_s + "' ,'" + tt + "')";
                    st.executeUpdate(s_pm);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Có lỗi", "", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnHoanThanhActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Quan_ly_muon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Quan_ly_muon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Quan_ly_muon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Quan_ly_muon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Quan_ly_muon().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHoanThanh;
    private javax.swing.JButton btnQuayL;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTable tabSach;
    private javax.swing.JTextField txtM_dg;
    private javax.swing.JTextField txtMas;
    // End of variables declaration//GEN-END:variables
}
