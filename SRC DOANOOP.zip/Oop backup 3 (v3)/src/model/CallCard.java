//Phieu muon tra
package model;
import java.util.Date;

public class CallCard //Phieu muon tra
{
    private static String card_ID; //ma phieu (map)
    private static int  borrowNum; //so luong muon (slm)
    
    private static String borrowDate; //ngay muon
    
    private static String returnDate; //ngay tra
    
    private static String status; //tinh trang

    public static void setCard_ID(String card_ID) 
    {
        CallCard.card_ID = card_ID;
    }

    public static String getCard_ID() 
    {
        return card_ID;
    }

    public static int getBorrowNum() 
    {
        return borrowNum;
    }

    public static String getBorrowDate() 
    {
        return borrowDate;
    }

    public static String getReturnDate() 
    {
        return returnDate;
    }

    public static String getStatus() 
    {
        return status;
    }

    public static void setBorrowNum(int borrowNum) 
    {
        CallCard.borrowNum = borrowNum;
    }

    public static void setBorrowDate(String borrowDate) 
    {
        CallCard.borrowDate = borrowDate;
    }

    public static void setReturnDate(String returnDate) 
    {
        CallCard.returnDate = returnDate;
    }

    public static void setStatus(String status) 
    {
        CallCard.status = status;
    }
     
}
