//Sach_PM
package model;
public class Book_Card {
    int number ; //so luong (s l)
    String Sta_tus; //Tinh_trang

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getSta_tus() {
        return Sta_tus;
    }

    public void setSta_tus(String Sta_tus) {
        this.Sta_tus = Sta_tus;
    }

    public Book_Card(int number, String Sta_tus) {
        this.number = number;
        this.Sta_tus = Sta_tus;
    }

    public Book_Card() {
    }
    
}
