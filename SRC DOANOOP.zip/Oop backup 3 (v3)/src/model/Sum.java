//Tong tien
package model;


public class Sum {
    float sum;

    public float getSum() {
        return sum;
    }

    public void setSum(float sum) {
        this.sum = sum;
    }

    public Sum() {
    }
    
}
