//Sach
package model;

public class Book {
    private static String bookName; //ten sach
    private static String book_ID; //ma sach (mas)
    private static String type; //the loai
    private static float price; //gia ban (giab)
    private static float deposit; //gia coc (giac)
    private static String author; //ten tac gia (tentg)
    private static String publisher; //nha xuat ban (nhaxb)
    private static int quantity ; //so luong bd (slbd)
    private static String location ; //vi tri

    public Book() {
    }
    

    public  String getBookName() {
        return bookName;
    }

    public static String getBook_ID() {
        return book_ID;
    }

    public static String getType() {
        return type;
    }

    public static float getPrice() {
        return price;
    }

    public static float getDeposit() {
        return deposit;
    }

    public static String getAuthor() {
        return author;
    }

    public static String getPublisher() {
        return publisher;
    }

    public static int getQuantity() {
        return quantity;
    }

    public static String getLocation() {
        return location;
    }

    public static void setBookName(String bookName) {
        Book.bookName = bookName;
    }

    public static void setBook_ID(String book_ID) {
        Book.book_ID = book_ID;
    }

    public static void setType(String type) {
        Book.type = type;
    }

    public static void setPrice(float price) {
        Book.price = price;
    }

    public static void setDeposit(float deposit) {
        Book.deposit = deposit;
    }

    public static void setAuthor(String author) {
        Book.author = author;
    }

    public static void setPublisher(String publisher) {
        Book.publisher = publisher;
    }

    public static void setQuantity(int quantity) {
        Book.quantity = quantity;
    }

    public static void setLocation(String location) {
        Book.location = location;
    }
    

    
}
