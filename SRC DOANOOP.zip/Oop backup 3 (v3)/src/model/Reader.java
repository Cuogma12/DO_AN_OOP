//Doc gia
package model;

import com.sun.jdi.connect.spi.Connection;
import java.sql.Statement;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class Reader {

    private static String rea_Name = ""; //Ten doc gia
    private static String phoneNum; //Sdt
    private static String birthDate; //ngay thang nam sinh
    private static String ID; //CCCD
    private static String rea_ID; //ma doc gia
    private static String R_pass; //mat khau
    private static String email;
    

    public Reader() {}
    
   
    public static void setRea_Name(String rea_Name) 
    {
        Reader.rea_Name = rea_Name;
    }

    public static void setPhoneNum(String phoneNum) 
    {
        Reader.phoneNum = phoneNum;
    }

    public static void setBirthDate(String birthDate) 
    {
        Reader.birthDate = birthDate;      
    }

    public static void setID(String ID) 
    {
        Reader.ID = ID;
    }

    public static void setRea_ID(String rea_ID) 
    {
        Reader.rea_ID = rea_ID;
    }

    public static void setR_Pass(String R_pass) 
    {
        Reader.R_pass = R_pass;
    }

    public static void setEmail(String email) 
    {
        Reader.email = email;
    }

    public static String getRea_Name() 
    {
        return rea_Name;
    }

    public static String getPhoneNum() 
    {
        return phoneNum;
    }

    public static String getBirthDate() 
    {

        return birthDate;
    }

    public static String getID()
    {
        return ID;
    }

    public static String getRea_ID() 
    {
        return rea_ID;
    }

    public static String getR_Pass() 
    {
        return R_pass;
    }

    public static String getEmail() 
    {
        return email;
    }

}
