package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectDB {

    public static Connection getConnection() {
        Connection con = null;
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            String url = "jdbc:mysql://localhost:3306/qltv";
            String user = "root";
            String pass = "123456";

            con = DriverManager.getConnection(url, user, pass);

        } catch (Exception e) {
            System.err.println(e.toString());
        }
        return con;
    }

    public static void closeConnection(Connection con) {
        if (con != null) {
            try {
                con.close();
            } catch (Exception e) {

            }
        }
    }

    public static void main(String[] args) {
    try {
    Connection con = getConnection();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT * FROM DOC_GIA");
    while (rs.next()) {
    System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDate(3)    );;
    
    }
    con.close();
    } catch (Exception e) {
    }
    }
}
