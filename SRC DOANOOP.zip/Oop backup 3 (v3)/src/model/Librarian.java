//Thuthu
package model;

public class Librarian {
    private static String lib_ID; //Ma thu thu (ma t)
    private static String lib_Name = ""; //Ten thu thu (tent t)
    private static String email;
    private static String L_pass; //lib_ID khau

    public static void setLib_ID(String lib_ID) {
        Librarian.lib_ID = lib_ID;
    }

    public static void setLib_Name(String lib_Name) {
        Librarian.lib_Name = lib_Name;
    }

    public static void setEmail(String email) {
        Librarian.email = email;
    }

    public static void setL_Pass(String L_pass) {
        Librarian.L_pass = L_pass;
    }

    public static String getLib_ID() {
        return lib_ID;
    }

    public static String getLib_Name() {
        return lib_Name;
    }

    public static String getEmail() {
        return email;
    }

    public static String getL_Pass() {
        return L_pass;
    }
    
}
