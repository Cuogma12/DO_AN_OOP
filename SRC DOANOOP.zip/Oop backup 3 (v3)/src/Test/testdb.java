/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import model.ConnectDB;
import java.sql.Connection;

/**
 *
 * @author chipn
 */
public class testdb {
    public static void main(String[] args) {
        Connection con = ConnectDB.getConnection();
        if(con!= null){
            System.out.println("OK");
        }
    }
 
}
